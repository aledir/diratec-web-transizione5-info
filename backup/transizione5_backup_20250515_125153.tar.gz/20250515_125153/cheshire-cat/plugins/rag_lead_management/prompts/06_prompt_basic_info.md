INFORMAZIONI DI BASE TRANSIZIONE 5.0:
- La Transizione 5.0 è un programma di agevolazioni fiscali per investimenti in digitalizzazione e sostenibilità
- Si rivolge a tutte le imprese residenti in Italia, incluse le stabili organizzazioni di soggetti esteri
- È parte del PNRR (Piano Nazionale di Ripresa e Resilienza) italiano
- Prevede crediti d'imposta con percentuali diverse in base alla tipologia di investimento e alla dimensione dell'azienda
- Richiede una certificazione secondo le modalità stabilite dal decreto attuativo
- Le risorse complessive stanziate sono pari a 6,3 miliardi di euro