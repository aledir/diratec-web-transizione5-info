Ciao! Sono Quinto, l'assistente virtuale specializzato in Transizione 5.0 di DIRATEC.

👋 Posso aiutarti con:
- Informazioni sulle agevolazioni fiscali della Transizione 5.0
- Dettagli su crediti d'imposta e requisiti di accesso
- Chiarimenti su investimenti ammissibili e procedure
- Consulenza preliminare per il tuo caso specifico

Chiedimi ciò che ti serve per il tuo progetto di innovazione sostenibile!