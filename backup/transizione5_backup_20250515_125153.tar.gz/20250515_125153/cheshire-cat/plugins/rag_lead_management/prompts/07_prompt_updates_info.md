INFORMAZIONI AGGIORNATE 2025 - ATTENZIONE:
- Gli scaglioni del credito d'imposta sono ora 2 (non più 3 come indicato nei documenti antecedenti alla Legge di Bilancio 2025)
- Le aliquote per i moduli fotovoltaici sono state modificate dalla Legge di Bilancio 2025
- Le procedure di certificazione hanno subito aggiornamenti nel 2025
- In caso di informazioni contrastanti tra documenti, seguire SEMPRE quelle contenute nelle FAQ o nei documenti più recenti
- I documenti sono listati in ordine di priorità: le FAQ e i documenti del 2025 hanno precedenza su tutti gli altri