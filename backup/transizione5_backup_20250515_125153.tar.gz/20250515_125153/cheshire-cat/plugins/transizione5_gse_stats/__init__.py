"""Plugin GSE Stats per Cheshire Cat."""
# Importa gli endpoint
from . import endpoints